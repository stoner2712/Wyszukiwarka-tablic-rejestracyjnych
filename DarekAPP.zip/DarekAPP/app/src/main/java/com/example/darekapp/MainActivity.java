package com.example.darekapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.darekapp.ui.main.MainFragment;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Button searchButton;
    TextView resultTextHolder;
    EditText editText;
    Map<String, String> SlownikTablic = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        StworzListeRejestracji();

        searchButton = findViewById(R.id.serachButton);
        resultTextHolder = findViewById(R.id.resultTextHolder);
        editText = findViewById(R.id.editText);

        searchButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view){
                SzukajRejestracji();
            }
        });
    }

    private void StworzListeRejestracji() {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open("tablice.txt"))))
        {
            String key = "";
            String value = "";

            while(reader.ready()){
                String[] line = reader.readLine().split(" ");
                StringBuilder sb = new StringBuilder();

                if(line.length >= 2){
                    key = line[0];

                    for(int i = 1; i < line.length; i++){
                        sb.append(line[i]);
                        sb.append(" ");
                    }
                    value = sb.toString();
                }
                SlownikTablic.put(key, value);
            }
        } catch (FileNotFoundException ex){
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void SzukajRejestracji()
    {
        String inputText = editText.getText().toString().toUpperCase();

        //Podano zła liczbe znakow
        if(inputText.length() > 3 || inputText.length() < 2){
            Toast.makeText(getApplicationContext(), "Podano nieprawidłowe znaki!", Toast.LENGTH_SHORT).show();
        }
        else{
            StringBuilder sb = new StringBuilder();
            sb.append("Szukana fraza: " + inputText + "\n");

            String wynik = SlownikTablic.get(inputText);

            if(wynik != null && wynik != ""){

                if(inputText.length()  > 1){ //Dla znalezienia Wojewodztwa na podstawie pierwszej litery
                    String firstLetter = inputText.substring(0,1);
                    String wojewodztwo = SlownikTablic.get(firstLetter);

                    sb.append("Województwo: " + wojewodztwo + "\n");
                    sb.append(wynik);
                }
                else{ //Tutaj tylko znaleziono wojewodztwo
                    sb.append("Województwo: " + wynik);
                }
            }
            else {
                sb.append("Niestety, nic nie znaleziono :( ");
            }
            resultTextHolder.setText(sb.toString());
        }
        editText.setText("");
        editText.setHint("Zacznij wpisywać rejestracje...");
    }
}
